package com.cg.jpaspring.controller;

import java.util.ArrayList;
import java.util.Map;

import javax.enterprise.inject.Model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.jpaspring.dto.Employee;
import com.cg.jpaspring.service.IEmploeeService;

@RestController
public class MyController {
	
	@Autowired
	private IEmploeeService service;
	
	@RequestMapping(value="display")
	public ModelAndView display(@RequestParam("id") int id, Model model) {
		Employee emp=service.search(id);
		if(emp!=null) {
			return new ModelAndView("display","temp",emp);
		}
		else
		return new ModelAndView("index");
	} 
	@RequestMapping(value="update")
	public ModelAndView update(@RequestParam("id") int id,Map<String,Object> model) {
		
		Employee emp=service.search(id);
		if(emp!=null) {
			
			ArrayList< String>  list=new ArrayList<>();
			list.add("managerr");
			list.add("asst manager");
			list.add("sr manager");
			model.put("desig",list);

			return new ModelAndView("update","temp",emp);
		}
		return null;
			
		
	}
	

}
