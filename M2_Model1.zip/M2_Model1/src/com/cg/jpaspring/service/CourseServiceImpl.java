package com.cg.jpaspring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.jpaspring.bean.Course;
import com.cg.jpaspring.dao.ICourseDao;
@Service
public class CourseServiceImpl implements ICourseService
{
	@Autowired
	ICourseDao dao;

	@Override
	public List<Course> getCourseDetails() {
		// TODO Auto-generated method stub
		return dao.getCourseDetails();
	}
	
	

}
