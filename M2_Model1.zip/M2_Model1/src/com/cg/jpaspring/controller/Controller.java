package com.cg.jpaspring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.jpaspring.bean.Course;
import com.cg.jpaspring.service.ICourseService;

@org.springframework.stereotype.Controller
public class Controller {
	
	@Autowired
	ICourseService service;
	
	@RequestMapping(value="course")
	public String c(){
		return "c";
		
	}
	
	@RequestMapping(value="cou", method=RequestMethod.GET)
	public ModelAndView course(Model model){
		List<Course> course2=service.getCourseDetails();
		model.addAttribute("courseList",course2);
		
		return new ModelAndView("coursedetails","temp",course2);
		
	}
	@RequestMapping(value="enroll", method=RequestMethod.GET)
	public ModelAndView enroll(Model model){
	
		
		return new ModelAndView("enroll","te",model);
		
	}
	
}
