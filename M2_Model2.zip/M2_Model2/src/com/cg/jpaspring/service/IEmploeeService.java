package com.cg.jpaspring.service;

import com.cg.jpaspring.dto.Employee;

public interface IEmploeeService {
	
	Employee search(int id);

}
