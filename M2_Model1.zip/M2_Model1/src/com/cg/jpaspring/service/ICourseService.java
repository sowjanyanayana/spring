package com.cg.jpaspring.service;

import java.util.List;

import com.cg.jpaspring.bean.Course;

public interface ICourseService {

	List<Course> getCourseDetails();

}
