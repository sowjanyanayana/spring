package com.cg.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value = "user")
public class UserController {

	ArrayList<String> cityList;
	ArrayList<String> skillList;

	@RequestMapping(value = "/showLogin")
	public String showLogin(Model model) {

		System.out.println("in show login method");
		model.addAttribute("login", new Login());

		return "login";

	}

	@RequestMapping(value = "/checkLogin")
	public String checkLogin() {
		return "loginSuccess";

	}

	@RequestMapping(value = "/showRegister")
	public String showRegister(Model model) {
		System.out.println("in register method");

		cityList = new ArrayList<String>();
		cityList.add("chennai");
		cityList.add("hyderabad");
		cityList.add("banglore");
		cityList.add("pune");

		skillList = new ArrayList<String>();
		skillList.add("java");
		skillList.add("python");
		skillList.add("hibernate");
		skillList.add("spring");

		model.addAttribute("cityList", cityList);
		model.addAttribute("skillList", skillList);
		model.addAttribute("register", new User());
		return "register";

	}

	@RequestMapping(value = "/checkRegister")
	public String checkRegister(@ModelAttribute("user")  @Valid User user,BindingResult result, Model model) {
		
		if(result.hasErrors()){
			System.out.println("error");
			model.addAttribute("cityList", cityList);
			model.addAttribute("skillList", skillList);
			return "register";
		}
		else
		{
			model.addAttribute("user", user);
			System.out.println("enter valid data");
			return "registerSuccess";
		}
		
		

	}
}
