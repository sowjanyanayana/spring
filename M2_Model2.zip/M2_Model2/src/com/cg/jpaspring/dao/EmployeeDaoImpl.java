package com.cg.jpaspring.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.jpaspring.dto.Employee;

@Repository
public class EmployeeDaoImpl implements IEmployeeDao {
	@PersistenceContext
	EntityManager em;

	@Override
	public Employee search(int id) {
		
		Employee employee= em.find(Employee.class,id);
		return employee;
	}

}
