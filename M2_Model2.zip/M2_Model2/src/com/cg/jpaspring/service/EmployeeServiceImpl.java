package com.cg.jpaspring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.jpaspring.dao.IEmployeeDao;
import com.cg.jpaspring.dto.Employee;

@Service
public class EmployeeServiceImpl implements IEmploeeService {
	@Autowired
	private IEmployeeDao dao;

	public Employee search(int id) {

		return dao.search(id);
	}

}
