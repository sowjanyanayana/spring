package com.cg.jpaspring.dao;

import com.cg.jpaspring.dto.Employee;

public interface IEmployeeDao {
	
	Employee search(int id);

}
