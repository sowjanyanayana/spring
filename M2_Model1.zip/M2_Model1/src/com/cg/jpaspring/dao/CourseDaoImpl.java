package com.cg.jpaspring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.jpaspring.bean.Course;

@Repository("dao")
public class CourseDaoImpl implements ICourseDao {
	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<Course> getCourseDetails() {
		
		TypedQuery<Course> query= em.createQuery("from Course",Course.class);
		
		return query.getResultList();
	}

	

}
