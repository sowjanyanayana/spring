package com.cg.jpaspring.dao;

import java.util.List;

import com.cg.jpaspring.bean.Course;

public interface ICourseDao {

	List<Course> getCourseDetails();
}
