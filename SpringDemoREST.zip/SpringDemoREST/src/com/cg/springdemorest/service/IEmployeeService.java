package com.cg.springdemorest.service;

import java.util.List;

import com.cg.springdemorest.beans.Employee;

public interface IEmployeeService {

	public List<Employee> getAllEmployee();
	public void addEmployee(Employee emp);
	public void deleteEmployee(int id);
	public Employee searchEmployee(int id);
	public void updateEmployee(Employee emp);

}
