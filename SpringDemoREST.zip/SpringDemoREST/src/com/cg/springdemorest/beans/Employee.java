package com.cg.springdemorest.beans;

public class Employee {

	private int empId;
	private String empName;
	private double salary;
	private String empDepartment;

	public Employee() {
		super();
	}

	public Employee(int empId, String empName, double salary,
			String empDepartment) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.empDepartment = empDepartment;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getEmpDepartment() {
		return empDepartment;
	}

	public void setEmpDepartment(String empDepartment) {
		this.empDepartment = empDepartment;
	}

}
